#define STIM_NQB_SIZE 4
// scale_bias [64]
L1_DATA int32_t ne16_scale_bias_avgpool[] = { 0 };
