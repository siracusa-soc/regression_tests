#define STIM_NQS_SIZE 1
// scale_shift [64]
L1_DATA int8_t ne16_scale_shift_no_normquant[] = { 0 };
